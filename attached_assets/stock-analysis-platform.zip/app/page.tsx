import { SearchBar } from "@/components/search-bar"
import { StockOverview } from "@/components/stock-overview"
import { StockTabs } from "@/components/stock-tabs"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 text-white">
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row md:items-center justify-between">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <div className="bg-emerald-500 h-8 w-8 rounded-md flex items-center justify-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-slate-950"
              >
                <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                <polyline points="16 7 22 7 22 13"></polyline>
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">StockSavvy</h1>
              <p className="text-xs text-slate-400">Advanced Technical & Fundamental Analysis</p>
            </div>
          </div>
          <SearchBar />
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <StockOverview />
        <StockTabs />
      </main>
    </div>
  )
}
