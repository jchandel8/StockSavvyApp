"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TechnicalAnalysis } from "@/components/technical-analysis"
import { PricePrediction } from "@/components/price-prediction"
import { NewsSection } from "@/components/news-section"
import { BacktestingSection } from "@/components/backtesting-section"

export function StockTabs() {
  const [activeTab, setActiveTab] = useState("technical")

  return (
    <Tabs defaultValue="technical" className="w-full" onValueChange={setActiveTab}>
      <TabsList className="grid grid-cols-4 mb-6 bg-slate-900 border border-slate-800 rounded-lg p-1">
        <TabsTrigger value="technical" className="data-[state=active]:bg-slate-800 data-[state=active]:text-white">
          Technical Analysis
        </TabsTrigger>
        <TabsTrigger value="prediction" className="data-[state=active]:bg-slate-800 data-[state=active]:text-white">
          Price Prediction
        </TabsTrigger>
        <TabsTrigger value="news" className="data-[state=active]:bg-slate-800 data-[state=active]:text-white">
          News
        </TabsTrigger>
        <TabsTrigger value="backtesting" className="data-[state=active]:bg-slate-800 data-[state=active]:text-white">
          Backtesting
        </TabsTrigger>
      </TabsList>

      <TabsContent value="technical">
        <TechnicalAnalysis />
      </TabsContent>

      <TabsContent value="prediction">
        <PricePrediction />
      </TabsContent>

      <TabsContent value="news">
        <NewsSection />
      </TabsContent>

      <TabsContent value="backtesting">
        <BacktestingSection />
      </TabsContent>
    </Tabs>
  )
}
