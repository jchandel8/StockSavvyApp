"use client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"
import { AlertCircle, ArrowDown, ArrowUp } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

// Sample data for the chart
const data = [
  { date: "Jan 2024", price: 180, volume: 80000000 },
  { date: "Feb 2024", price: 190, volume: 90000000 },
  { date: "Mar 2024", price: 200, volume: 100000000 },
  { date: "Apr 2024", price: 210, volume: 120000000 },
  { date: "May 2024", price: 220, volume: 110000000 },
  { date: "Jun 2024", price: 230, volume: 130000000 },
  { date: "Jul 2024", price: 240, volume: 150000000 },
  { date: "Aug 2024", price: 230, volume: 140000000 },
  { date: "Sep 2024", price: 220, volume: 120000000 },
  { date: "Oct 2024", price: 210, volume: 100000000 },
  { date: "Nov 2024", price: 200, volume: 90000000 },
  { date: "Dec 2024", price: 190, volume: 80000000 },
  { date: "Jan 2025", price: 180, volume: 70000000 },
  { date: "Feb 2025", price: 190, volume: 90000000 },
  { date: "Mar 2025", price: 196.98, volume: 100000000 },
]

export function TechnicalAnalysis() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2 border-slate-800 bg-slate-900">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Stock Price Chart</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={data}
                margin={{
                  top: 10,
                  right: 30,
                  left: 0,
                  bottom: 0,
                }}
              >
                <defs>
                  <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="date"
                  tick={{ fill: "#94a3b8" }}
                  axisLine={{ stroke: "#334155" }}
                  tickLine={{ stroke: "#334155" }}
                />
                <YAxis
                  domain={["dataMin - 10", "dataMax + 10"]}
                  tick={{ fill: "#94a3b8" }}
                  axisLine={{ stroke: "#334155" }}
                  tickLine={{ stroke: "#334155" }}
                />
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1e293b",
                    borderColor: "#334155",
                    color: "#f8fafc",
                  }}
                />
                <Area type="monotone" dataKey="price" stroke="#10b981" fillOpacity={1} fill="url(#colorPrice)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-4">
            <div className="h-[100px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={data}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 0,
                    bottom: 5,
                  }}
                >
                  <XAxis
                    dataKey="date"
                    tick={{ fill: "#94a3b8" }}
                    axisLine={{ stroke: "#334155" }}
                    tickLine={{ stroke: "#334155" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      borderColor: "#334155",
                      color: "#f8fafc",
                    }}
                  />
                  <Bar dataKey="volume" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        <Card className="border-slate-800 bg-slate-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Technical Analysis Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Current Price</span>
                <span className="font-semibold">$196.98</span>
              </div>

              <Separator className="bg-slate-800" />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-slate-400 text-sm mb-1">RSI</div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">40.93</span>
                    <Badge variant="outline" className="text-yellow-400 border-yellow-400/20 bg-yellow-400/10">
                      Neutral
                    </Badge>
                  </div>
                </div>

                <div>
                  <div className="text-slate-400 text-sm mb-1">MACD</div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">-7.78</span>
                    <Badge variant="outline" className="text-red-400 border-red-400/20 bg-red-400/10">
                      Bearish
                    </Badge>
                  </div>
                </div>
              </div>

              <Separator className="bg-slate-800" />

              <div>
                <h4 className="font-medium mb-2">Buy Signals</h4>
                <div className="flex items-center gap-2 text-slate-400">
                  <AlertCircle className="h-4 w-4" />
                  <span className="text-sm">No buy signals detected</span>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Sell Signals</h4>
                <div className="flex items-center gap-2 text-slate-400">
                  <AlertCircle className="h-4 w-4" />
                  <span className="text-sm">No sell signals detected</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-800 bg-slate-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Moving Averages</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <div className="text-slate-400 text-sm">SMA 20</div>
                  <div className="font-semibold">$204.56</div>
                </div>
                <Badge variant="outline" className="text-red-400 border-red-400/20 bg-red-400/10">
                  <ArrowDown className="h-3 w-3 mr-1" />
                  Below
                </Badge>
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <div className="text-slate-400 text-sm">SMA 50</div>
                  <div className="font-semibold">$210.32</div>
                </div>
                <Badge variant="outline" className="text-red-400 border-red-400/20 bg-red-400/10">
                  <ArrowDown className="h-3 w-3 mr-1" />
                  Below
                </Badge>
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <div className="text-slate-400 text-sm">SMA 200</div>
                  <div className="font-semibold">$190.45</div>
                </div>
                <Badge variant="outline" className="text-emerald-400 border-emerald-400/20 bg-emerald-400/10">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  Above
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
