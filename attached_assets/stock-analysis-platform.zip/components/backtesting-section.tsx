"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { ArrowRight, Calendar, Play } from "lucide-react"

const backtestData = [
  { date: "2024-01", strategy: 10000, benchmark: 10000 },
  { date: "2024-02", strategy: 10500, benchmark: 10200 },
  { date: "2024-03", strategy: 11200, benchmark: 10400 },
  { date: "2024-04", strategy: 10800, benchmark: 10300 },
  { date: "2024-05", strategy: 11500, benchmark: 10600 },
  { date: "2024-06", strategy: 12200, benchmark: 10900 },
  { date: "2024-07", strategy: 12800, benchmark: 11100 },
  { date: "2024-08", strategy: 13500, benchmark: 11400 },
  { date: "2024-09", strategy: 13200, benchmark: 11200 },
  { date: "2024-10", strategy: 14000, benchmark: 11500 },
  { date: "2024-11", strategy: 14800, benchmark: 11800 },
  { date: "2024-12", strategy: 15500, benchmark: 12100 },
  { date: "2025-01", strategy: 16200, benchmark: 12400 },
  { date: "2025-02", strategy: 16800, benchmark: 12700 },
  { date: "2025-03", strategy: 17500, benchmark: 13000 },
]

export function BacktestingSection() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-1 border-slate-800 bg-slate-900">
        <CardHeader>
          <CardTitle>Backtest Parameters</CardTitle>
          <CardDescription>Configure your strategy parameters</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="strategy">Strategy</Label>
            <Select defaultValue="momentum">
              <SelectTrigger id="strategy" className="bg-slate-800 border-slate-700">
                <SelectValue placeholder="Select strategy" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="momentum">Momentum</SelectItem>
                <SelectItem value="meanreversion">Mean Reversion</SelectItem>
                <SelectItem value="breakout">Breakout</SelectItem>
                <SelectItem value="macd">MACD Crossover</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="period">Time Period</Label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Input
                  id="startDate"
                  type="text"
                  placeholder="Start Date"
                  defaultValue="01/01/2024"
                  className="bg-slate-800 border-slate-700 pl-9"
                />
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
              </div>
              <ArrowRight className="h-4 w-4 text-slate-400" />
              <div className="relative flex-1">
                <Input
                  id="endDate"
                  type="text"
                  placeholder="End Date"
                  defaultValue="03/31/2025"
                  className="bg-slate-800 border-slate-700 pl-9"
                />
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="initialCapital">Initial Capital</Label>
            <Input id="initialCapital" type="text" defaultValue="$10,000" className="bg-slate-800 border-slate-700" />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="riskLevel">Risk Level</Label>
              <span className="text-sm text-slate-400">Medium</span>
            </div>
            <Slider defaultValue={[50]} max={100} step={1} className="py-4" />
          </div>

          <div className="pt-4">
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
              <Play className="h-4 w-4 mr-2" />
              Run Backtest
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="lg:col-span-2 border-slate-800 bg-slate-900">
        <CardHeader>
          <CardTitle>Backtest Results</CardTitle>
          <CardDescription>Strategy performance vs. benchmark</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={backtestData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis
                  dataKey="date"
                  tick={{ fill: "#94a3b8" }}
                  axisLine={{ stroke: "#334155" }}
                  tickLine={{ stroke: "#334155" }}
                />
                <YAxis
                  tick={{ fill: "#94a3b8" }}
                  axisLine={{ stroke: "#334155" }}
                  tickLine={{ stroke: "#334155" }}
                  tickFormatter={(value) => `$${value.toLocaleString()}`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1e293b",
                    borderColor: "#334155",
                    color: "#f8fafc",
                  }}
                  formatter={(value) => [`$${Number(value).toLocaleString()}`, undefined]}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="strategy"
                  name="Momentum Strategy"
                  stroke="#10b981"
                  activeDot={{ r: 8 }}
                />
                <Line type="monotone" dataKey="benchmark" name="S&P 500" stroke="#3b82f6" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <StatCard title="Total Return" value="75.0%" comparison="vs. 30.0%" positive={true} />
            <StatCard title="Annualized Return" value="56.3%" comparison="vs. 22.5%" positive={true} />
            <StatCard title="Sharpe Ratio" value="1.85" comparison="vs. 1.20" positive={true} />
            <StatCard title="Max Drawdown" value="-8.3%" comparison="vs. -5.2%" positive={false} />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

interface StatCardProps {
  title: string
  value: string
  comparison: string
  positive: boolean
}

function StatCard({ title, value, comparison, positive }: StatCardProps) {
  return (
    <div className="bg-slate-800/50 rounded-lg p-3">
      <div className="text-sm text-slate-400 mb-1">{title}</div>
      <div className="text-xl font-bold">{value}</div>
      <div className={`text-xs ${positive ? "text-emerald-400" : "text-red-400"}`}>{comparison}</div>
    </div>
  )
}
