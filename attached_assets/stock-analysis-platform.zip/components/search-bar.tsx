"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"

export function SearchBar() {
  const [open, setOpen] = useState(false)

  return (
    <div className="w-full md:w-96">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className="w-full justify-between border-slate-700 bg-slate-800/50 hover:bg-slate-800 text-slate-300"
          >
            <div className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              <span>Search stocks and crypto...</span>
            </div>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="p-0 w-full md:w-96 border-slate-700 bg-slate-800">
          <Command>
            <CommandInput placeholder="Search stocks and crypto..." />
            <CommandList>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup heading="Stocks">
                <CommandItem className="cursor-pointer hover:bg-slate-700">
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2">
                      <div className="bg-blue-500/20 text-blue-400 h-8 w-8 rounded-md flex items-center justify-center font-semibold">
                        AAPL
                      </div>
                      <div>
                        <p className="font-medium">Apple Inc.</p>
                        <p className="text-xs text-slate-400">NASDAQ: AAPL</p>
                      </div>
                    </div>
                    <span className="text-emerald-400">$196.98</span>
                  </div>
                </CommandItem>
                <CommandItem className="cursor-pointer hover:bg-slate-700">
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2">
                      <div className="bg-red-500/20 text-red-400 h-8 w-8 rounded-md flex items-center justify-center font-semibold">
                        TSLA
                      </div>
                      <div>
                        <p className="font-medium">Tesla Inc.</p>
                        <p className="text-xs text-slate-400">NASDAQ: TSLA</p>
                      </div>
                    </div>
                    <span className="text-red-400">$172.63</span>
                  </div>
                </CommandItem>
              </CommandGroup>
              <CommandGroup heading="Crypto">
                <CommandItem className="cursor-pointer hover:bg-slate-700">
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2">
                      <div className="bg-amber-500/20 text-amber-400 h-8 w-8 rounded-md flex items-center justify-center font-semibold">
                        BTC
                      </div>
                      <div>
                        <p className="font-medium">Bitcoin</p>
                        <p className="text-xs text-slate-400">BTC/USD</p>
                      </div>
                    </div>
                    <span className="text-emerald-400">$66,245.78</span>
                  </div>
                </CommandItem>
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  )
}
