"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink } from "lucide-react"

const newsItems = [
  {
    title: "TSMC Confident Amid Trump Tariff Turmoil: CEO CC Wei Says No Change In Customer Behavior",
    subtitle: "Despite Nvidia H20 Chip Curbs - NVIDIA (NASDAQ:NVDA), Apple (NASDAQ:AAPL)",
    content:
      "Taiwan Semiconductor Manufacturing Co. Ltd. TSM remains optimistic despite ongoing geopolitical tensions. CEO CC Wei stated that customer behavior has not changed, even amid recent challenges such as the Nvidia Corporation NVDA H20 chip facing clamdown and tariff-related uncertainties.",
    source: "Benzinga",
    sentiment: "Neutral",
    date: "4/17/2025",
  },
  {
    title: "Top Analyst Reports for Apple, Philip Morris & Sony",
    subtitle: "",
    content:
      "Today's Research Daily features new research reports on 16 major stocks, including Bank of Apple Inc. (AAPL), Philip Morris International Inc. (PM) and Sony Group Corp. (SONY), as well as a micro-cap stock Vaso Corp. (VASO).",
    source: "Zacks Commentary",
    sentiment: "Neutral",
    date: "4/17/2025",
  },
  {
    title: "Google Scores Partial Win In Antitrust Case But Faces Setback On Publisher Tools",
    subtitle: "Alphabet (NASDAQ:GOOGL)",
    content:
      "US Department of Justice wins antitrust case against Google, ruling it maintained a monopoly in ad tech through anticompetitive practices. Google faces appeals after court dismisses some antitrust claims but supports the Justice Department's push for a breakup.",
    source: "Benzinga",
    sentiment: "Neutral",
    date: "4/17/2025",
  },
  {
    title: "Temu And Shein To Raise Prices Amid US Tariffs, Slash Ad Spend On Apple, Meta",
    subtitle: "PDD Holdings (NASDAQ:PDD)",
    content:
      "Temu and Shein to raise prices starting April 25, shifting tariff burden onto consumers as U.S. tariffs on Chinese goods increase. Temu cuts U.S. ad spend and sees sharp decline in App Store rankings, while facing impact of 145% tariff on Chinese imports.",
    source: "Benzinga",
    sentiment: "Neutral",
    date: "4/17/2025",
  },
  {
    title: "Avoid The Mistake Countless Investors And Advisors Are Making, Oral Weight Loss Drug Is Almost Here",
    subtitle: "",
    content:
      "To gain an edge, this is what you need to know today. Please click here for an enlarged chart of iShares 20+ Year Treasury Bond ETF (TLT). Countless investors and investment advisors are losing significant money because they are stuck in the orthodox thinking that long bonds are a safe...",
    source: "Benzinga",
    sentiment: "Neutral",
    date: "4/17/2025",
  },
]

export function NewsSection() {
  return (
    <div className="space-y-6">
      {newsItems.map((item, index) => (
        <Card key={index} className="border-slate-800 bg-slate-900 overflow-hidden">
          <CardHeader className="pb-2">
            <div className="flex justify-between">
              <div>
                <CardTitle className="text-lg font-medium">{item.title}</CardTitle>
                {item.subtitle && <CardDescription>{item.subtitle}</CardDescription>}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-slate-300">{item.content}</p>
          </CardContent>
          <CardFooter className="flex justify-between border-t border-slate-800 pt-4 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Source: {item.source}</span>
              <Badge variant="outline" className="text-slate-400 border-slate-700">
                {item.sentiment}
              </Badge>
            </div>
            <div className="flex items-center gap-1 text-blue-400 hover:text-blue-300 cursor-pointer">
              <span>Read more</span>
              <ExternalLink className="h-3 w-3" />
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
