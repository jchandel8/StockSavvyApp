"use client"

import { ArrowUpRight, Info } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function StockOverview() {
  return (
    <div className="mb-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <div className="bg-blue-500/20 text-blue-400 h-10 w-10 rounded-md flex items-center justify-center font-semibold">
              AAPL
            </div>
            <h2 className="text-2xl font-bold">Apple Inc.</h2>
            <span className="text-xs px-2 py-1 rounded bg-slate-800 text-slate-400">Major Exchange</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Card className="border-slate-800 bg-slate-900">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <div className="text-xs text-slate-400">Current Price</div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-3 w-3 text-slate-500" />
                    </TooltipTrigger>
                    <TooltipContent className="bg-slate-800 border-slate-700">
                      <p className="text-xs">Last updated: 4/17/2025, 11:43 PM</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold">$196.98</span>
                <span className="text-xs px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 flex items-center">
                  <ArrowUpRight className="h-3 w-3 mr-0.5" />
                  1.39%
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-800 bg-slate-900">
            <CardContent className="p-3">
              <div className="text-xs text-slate-400">Market Cap</div>
              <div className="text-xl font-bold">$2.71T</div>
            </CardContent>
          </Card>

          <Card className="border-slate-800 bg-slate-900">
            <CardContent className="p-3">
              <div className="text-xs text-slate-400">P/E Ratio</div>
              <div className="text-xl font-bold">28.92</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
