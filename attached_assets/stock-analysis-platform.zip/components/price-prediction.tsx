"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowDown, ArrowUp, Minus } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export function PricePrediction() {
  return (
    <div className="space-y-6">
      <Card className="border-slate-800 bg-slate-900">
        <CardHeader>
          <CardTitle>Price Prediction Model</CardTitle>
          <CardDescription>
            Our advanced price prediction model utilizes a combination of machine learning techniques, technical
            indicators, seasonal patterns, and market regime analysis.
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <PredictionCard
          period="1 Day"
          direction="UP"
          confidence={70.7}
          targetPrice={196.62}
          currentPrice={196.98}
          percentChange={-0.19}
          predictedHigh={198.38}
          predictedLow={194.85}
        />

        <PredictionCard
          period="1 Week"
          direction="NEUTRAL"
          confidence={0}
          targetPrice={196.98}
          currentPrice={196.98}
          percentChange={0}
          predictedHigh={202.29}
          predictedLow={191.67}
        />

        <PredictionCard
          period="1 Month"
          direction="UP"
          confidence={60.2}
          targetPrice={195.82}
          currentPrice={196.98}
          percentChange={-0.59}
          predictedHigh={204.67}
          predictedLow={186.98}
        />

        <PredictionCard
          period="3 Months"
          direction="UP"
          confidence={55.0}
          targetPrice={192.33}
          currentPrice={196.98}
          percentChange={-2.36}
          predictedHigh={206.48}
          predictedLow={178.18}
        />

        <PredictionCard
          period="6 Months"
          direction="UP"
          confidence={51.9}
          targetPrice={186.29}
          currentPrice={196.98}
          percentChange={-5.43}
          predictedHigh={207.52}
          predictedLow={165.07}
        />
      </div>
    </div>
  )
}

interface PredictionCardProps {
  period: string
  direction: "UP" | "DOWN" | "NEUTRAL"
  confidence: number
  targetPrice: number
  currentPrice: number
  percentChange: number
  predictedHigh: number
  predictedLow: number
}

function PredictionCard({
  period,
  direction,
  confidence,
  targetPrice,
  currentPrice,
  percentChange,
  predictedHigh,
  predictedLow,
}: PredictionCardProps) {
  const getDirectionBadge = () => {
    if (direction === "UP") {
      return (
        <Badge className="bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 border-0">
          <ArrowUp className="h-3 w-3 mr-1" />
          UP
        </Badge>
      )
    } else if (direction === "DOWN") {
      return (
        <Badge className="bg-red-500/20 text-red-400 hover:bg-red-500/30 border-0">
          <ArrowDown className="h-3 w-3 mr-1" />
          DOWN
        </Badge>
      )
    } else {
      return (
        <Badge className="bg-slate-500/20 text-slate-400 hover:bg-slate-500/30 border-0">
          <Minus className="h-3 w-3 mr-1" />
          NEUTRAL
        </Badge>
      )
    }
  }

  const getPercentChangeColor = () => {
    if (percentChange > 0) {
      return "text-emerald-400"
    } else if (percentChange < 0) {
      return "text-red-400"
    } else {
      return "text-slate-400"
    }
  }

  return (
    <Card className="border-slate-800 bg-slate-900">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium">{period} Forecast</CardTitle>
          {getDirectionBadge()}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="text-slate-400 text-sm">Confidence</span>
              <span className="text-sm font-medium">{confidence.toFixed(1)}%</span>
            </div>
            <Progress value={confidence} className="h-2 bg-slate-800" indicatorClassName="bg-blue-500" />
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-400">Target Price</span>
            <div className="flex items-center gap-1">
              <span className="font-semibold">${targetPrice.toFixed(2)}</span>
              <span className={`text-xs ${getPercentChangeColor()}`}>
                ({percentChange > 0 ? "+" : ""}
                {percentChange.toFixed(2)}%)
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-slate-400 text-sm mb-1">Predicted High</div>
              <div className="font-semibold">${predictedHigh.toFixed(2)}</div>
            </div>

            <div>
              <div className="text-slate-400 text-sm mb-1">Predicted Low</div>
              <div className="font-semibold">${predictedLow.toFixed(2)}</div>
            </div>
          </div>

          <div className="pt-2">
            <div className="relative h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="absolute left-0 top-0 h-full bg-slate-600"
                style={{
                  width: `${((targetPrice - predictedLow) / (predictedHigh - predictedLow)) * 100}%`,
                }}
              ></div>
              <div
                className="absolute left-0 top-0 h-full bg-blue-500 w-1"
                style={{
                  left: `${((currentPrice - predictedLow) / (predictedHigh - predictedLow)) * 100}%`,
                }}
              ></div>
            </div>
            <div className="flex justify-between mt-1 text-xs text-slate-400">
              <span>${predictedLow.toFixed(2)}</span>
              <span>${predictedHigh.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
